import urllib2
import time
with open('../../crawler/seeds', 'r') as seed_file:
	for artist in seed_file:
		time.sleep(3)	
		artist_name = artist.replace('Ar:','').strip().lower()
		print artist_name
		with open(artist_name, 'r') as xml_file:
			index = 0
			xml_str = ""
			for line in xml_file:
				if index != 0 and line != "":
					xml_str += line.strip()
				index += 1

			req = urllib2.Request(url='http://greenwebcache.appspot.com/rest/metrics', data=xml_str)
			response = urllib2.urlopen(req)
			print response.read()
